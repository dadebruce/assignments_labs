# Files for Lab 2 of EMSE6992

## Part A

* [Lab_2_A_Live.ipynb](https://github.com/bsharvey/EMSEDataAnalytics/blob/master/EMSE6992_Labs/lab2/Lab_2_A_Live.ipynb) - Part 1
* [Lab_2_A_Johanna.ipynb](https://github.com/bsharvey/EMSEDataAnalytics/blob/master/EMSE6992_Labs/lab2/Lab_2_A_Johanna.ipynb) - Part 2
* [Lab_2_A_Live_Ray_Final.ipynb](https://github.com/bsharvey/EMSEDataAnalytics/blob/master/EMSE6992_Labs/lab2/Lab_2_A_Live_Ray_Final.ipynb) - Another example

## Part B

* [Lab_2_B.ipynb](https://github.com/bsharvey/EMSEDataAnalytics/blob/master/EMSE6992_Labs/lab2/Lab_2_B.ipynb) - Reddit example
