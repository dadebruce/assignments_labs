# ESMEDataAnalytics
GW EMSE Data Science Course

#### Repository for assignments and labs.
##### Assignment 1 - You will use techniques from Lab 3
##### Assignment 2 - You will use techniques from Lab 4, 5, 6
##### Assignment 3 - You will use techniques form Lab 10
##### Assignment 4 - You will use techniques form Lab 9
